import React, { useState } from 'react';
import { Layers, Plus, Trash2, Link as LinkIcon } from 'lucide-react';
import { FooterColumnItem, LandingCmsConfig } from '../../../../types/landingCms';

interface FooterTabProps {
  config: LandingCmsConfig;
  onChange: (updates: Partial<LandingCmsConfig>) => void;
}

export const FooterTab: React.FC<FooterTabProps> = ({ config, onChange }) => {
  const [newColTitle, setNewColTitle] = useState('');
  const [activeColId, setActiveColId] = useState<string | null>(null);
  const [newLinkLabel, setNewLinkLabel] = useState('');
  const [newLinkUrl, setNewLinkUrl] = useState('#');

  const columns = config.footerColumns || [];

  const handleAddColumn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newColTitle.trim()) return;
    const newCol: FooterColumnItem = {
      id: 'fcol-' + Date.now(),
      title: newColTitle.trim(),
      links: [],
    };
    onChange({ footerColumns: [...columns, newCol] });
    setNewColTitle('');
  };

  const handleDeleteColumn = (id: string) => {
    onChange({ footerColumns: columns.filter(c => c.id !== id) });
  };

  const handleAddLinkToColumn = (columnId: string) => {
    if (!newLinkLabel.trim()) return;
    const updated = columns.map(c => {
      if (c.id === columnId) {
        return {
          ...c,
          links: [
            ...c.links,
            { id: 'link-' + Date.now(), label: newLinkLabel.trim(), url: newLinkUrl.trim() || '#' },
          ],
        };
      }
      return c;
    });
    onChange({ footerColumns: updated });
    setNewLinkLabel('');
    setNewLinkUrl('#');
    setActiveColId(null);
  };

  const handleDeleteLink = (columnId: string, linkId: string) => {
    const updated = columns.map(c => {
      if (c.id === columnId) {
        return { ...c, links: c.links.filter(l => l.id !== linkId) };
      }
      return c;
    });
    onChange({ footerColumns: updated });
  };

  return (
    <div className="space-y-6 text-xs text-stone-800">
      {/* General Footer Text */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 border-b pb-3 border-stone-100">
          <Layers className="w-4 h-4 text-emerald-700" />
          <h3 className="font-bold text-stone-900 text-sm">Footer Branding & Copyright</h3>
        </div>

        <div className="space-y-3">
          <div>
            <label className="block font-semibold text-stone-700 mb-1">Footer Narrative Summary</label>
            <textarea
              rows={3}
              value={config.footerDescription}
              onChange={e => onChange({ footerDescription: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-stone-300 leading-relaxed"
            />
          </div>

          <div>
            <label className="block font-semibold text-stone-700 mb-1">Copyright Line</label>
            <input
              type="text"
              value={config.footerCopyright}
              onChange={e => onChange({ footerCopyright: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-stone-300 font-medium"
            />
          </div>
        </div>
      </div>

      {/* Footer Navigation Columns */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b pb-3 border-stone-100">
          <h3 className="font-bold text-stone-900 text-sm">Footer Link Columns</h3>
          <span className="text-[11px] text-stone-400">{columns.length} Columns</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {columns.map(col => (
            <div key={col.id} className="p-4 rounded-xl border border-stone-200 bg-stone-50 space-y-3">
              <div className="flex items-center justify-between">
                <input
                  type="text"
                  value={col.title}
                  onChange={e => {
                    const next = columns.map(c =>
                      c.id === col.id ? { ...c, title: e.target.value } : c
                    );
                    onChange({ footerColumns: next });
                  }}
                  className="font-bold text-stone-900 text-xs px-2 py-1 rounded-lg border border-stone-300 bg-white"
                />
                <button
                  type="button"
                  onClick={() => handleDeleteColumn(col.id)}
                  className="p-1 rounded-md hover:bg-red-50 text-red-600 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Links */}
              <div className="space-y-1.5">
                {col.links.map(link => (
                  <div
                    key={link.id}
                    className="p-1.5 rounded-lg bg-white border border-stone-200 flex items-center justify-between text-[11px]"
                  >
                    <span className="font-medium text-stone-700 truncate">{link.label}</span>
                    <button
                      type="button"
                      onClick={() => handleDeleteLink(col.id, link.id)}
                      className="text-stone-400 hover:text-red-600 p-0.5"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Add Link Form */}
              {activeColId === col.id ? (
                <div className="p-2 bg-white rounded-lg border border-emerald-300 space-y-1.5">
                  <input
                    type="text"
                    value={newLinkLabel}
                    onChange={e => setNewLinkLabel(e.target.value)}
                    placeholder="Link Label"
                    className="w-full px-2 py-1 rounded border border-stone-300 text-[11px]"
                  />
                  <input
                    type="text"
                    value={newLinkUrl}
                    onChange={e => setNewLinkUrl(e.target.value)}
                    placeholder="URL (e.g. #gis)"
                    className="w-full px-2 py-1 rounded border border-stone-300 font-mono text-[10px]"
                  />
                  <div className="flex justify-end gap-1 pt-1">
                    <button
                      type="button"
                      onClick={() => setActiveColId(null)}
                      className="px-2 py-1 rounded text-stone-500 hover:bg-stone-100 text-[10px]"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAddLinkToColumn(col.id)}
                      className="px-2.5 py-1 rounded bg-emerald-700 text-white font-bold text-[10px]"
                    >
                      Save Link
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setActiveColId(col.id)}
                  className="w-full py-1 rounded-lg border border-dashed border-stone-300 hover:border-emerald-600 text-stone-600 text-[11px] font-semibold flex items-center justify-center gap-1 cursor-pointer bg-white"
                >
                  <Plus className="w-3 h-3" /> Add Link
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Add Column */}
        <form onSubmit={handleAddColumn} className="pt-3 border-t border-stone-100 flex gap-2">
          <input
            type="text"
            value={newColTitle}
            onChange={e => setNewColTitle(e.target.value)}
            placeholder="New Column Title (e.g. Citizen Resources)"
            className="px-3 py-1.5 rounded-xl border border-stone-300 w-64"
          />
          <button
            type="submit"
            className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> Add Column
          </button>
        </form>
      </div>
    </div>
  );
};
