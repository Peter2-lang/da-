import React, { useState } from 'react';
import { GraduationCap, Plus, Trash2, ArrowUp, ArrowDown, Eye, EyeOff, Image as ImageIcon } from 'lucide-react';
import { AboutCardItem, LandingCmsConfig } from '../../../../types/landingCms';

interface AboutTabProps {
  config: LandingCmsConfig;
  onChange: (updates: Partial<LandingCmsConfig>) => void;
  onOpenMediaPicker?: (targetField: string) => void;
}

export const AboutTab: React.FC<AboutTabProps> = ({ config, onChange, onOpenMediaPicker }) => {
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const aboutCards = config.aboutCards || [];

  const handleToggleVisible = (id: string) => {
    const updated = aboutCards.map(c => (c.id === id ? { ...c, visible: !c.visible } : c));
    onChange({ aboutCards: updated });
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const newIdx = direction === 'up' ? index - 1 : index + 1;
    if (newIdx < 0 || newIdx >= aboutCards.length) return;
    const clone = [...aboutCards];
    const temp = clone[index];
    clone[index] = clone[newIdx];
    clone[newIdx] = temp;
    onChange({ aboutCards: clone.map((c, i) => ({ ...c, order: i + 1 })) });
  };

  const handleDelete = (id: string) => {
    onChange({ aboutCards: aboutCards.filter(c => c.id !== id) });
  };

  const handleUpdateCard = (id: string, updates: Partial<AboutCardItem>) => {
    onChange({
      aboutCards: aboutCards.map(c => (c.id === id ? { ...c, ...updates } : c)),
    });
  };

  const handleAddCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const newCard: AboutCardItem = {
      id: 'about-' + Date.now(),
      title: newTitle.trim(),
      description: newDesc.trim(),
      icon: 'ShieldCheck',
      visible: true,
      order: aboutCards.length + 1,
    };
    onChange({ aboutCards: [...aboutCards, newCard] });
    setNewTitle('');
    setNewDesc('');
  };

  return (
    <div className="space-y-6 text-xs text-stone-800">
      {/* Main Section Content */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 border-b pb-3 border-stone-100">
          <GraduationCap className="w-4 h-4 text-emerald-700" />
          <h3 className="font-bold text-stone-900 text-sm">About Section Main Copy & Image</h3>
        </div>

        <div className="space-y-3">
          <div>
            <label className="block font-semibold text-stone-700 mb-1">Section Title</label>
            <input
              type="text"
              value={config.aboutTitle}
              onChange={e => onChange({ aboutTitle: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-stone-300 font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block font-semibold text-stone-700 mb-1">Narrative Description</label>
            <textarea
              rows={4}
              value={config.aboutDescription}
              onChange={e => onChange({ aboutDescription: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-600 focus:outline-hidden leading-relaxed"
            />
          </div>

          <div>
            <label className="block font-semibold text-stone-700 mb-1">Featured Photo URL (SLSU / Extension / Farm)</label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={config.aboutImageUrl}
                onChange={e => onChange({ aboutImageUrl: e.target.value })}
                className="flex-1 px-3 py-2 rounded-xl border border-stone-300 font-mono text-[11px]"
              />
              {onOpenMediaPicker && (
                <button
                  type="button"
                  onClick={() => onOpenMediaPicker('aboutImageUrl')}
                  className="px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold border border-emerald-300 cursor-pointer"
                >
                  Media Library
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Dynamic About Pillars / Cards */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b pb-3 border-stone-100">
          <h3 className="font-bold text-stone-900 text-sm">About Highlight Cards & Key Mandates</h3>
          <span className="text-[11px] text-stone-400">{aboutCards.length} Cards</span>
        </div>

        <div className="space-y-3">
          {aboutCards.map((card, idx) => (
            <div
              key={card.id}
              className={`p-3.5 rounded-xl border space-y-2 transition ${
                card.visible ? 'bg-stone-50 border-stone-200' : 'bg-stone-100/60 border-stone-200 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <span className="font-mono text-stone-400 text-[11px]">#{idx + 1}</span>
                <input
                  type="text"
                  value={card.title}
                  onChange={e => handleUpdateCard(card.id, { title: e.target.value })}
                  className="flex-1 px-2.5 py-1 rounded-lg border border-stone-300 bg-white font-bold text-stone-900 text-xs"
                />
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleToggleVisible(card.id)}
                    className="p-1 rounded-md hover:bg-stone-200 text-stone-600 cursor-pointer"
                  >
                    {card.visible ? <Eye className="w-3.5 h-3.5 text-emerald-700" /> : <EyeOff className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    type="button"
                    disabled={idx === 0}
                    onClick={() => handleMove(idx, 'up')}
                    className="p-1 rounded-md hover:bg-stone-200 text-stone-600 disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    disabled={idx === aboutCards.length - 1}
                    onClick={() => handleMove(idx, 'down')}
                    className="p-1 rounded-md hover:bg-stone-200 text-stone-600 disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(card.id)}
                    className="p-1 rounded-md hover:bg-red-50 text-red-600 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <textarea
                rows={2}
                value={card.description}
                onChange={e => handleUpdateCard(card.id, { description: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 bg-white text-[11px] leading-relaxed"
                placeholder="Card description text"
              />
            </div>
          ))}
        </div>

        {/* Add Card Form */}
        <form onSubmit={handleAddCard} className="pt-3 border-t border-stone-100 space-y-2">
          <span className="font-semibold text-stone-700 block text-xs">Add New Highlight Card</span>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={newTitle}
              onChange={e => setNewTitle(e.target.value)}
              placeholder="Card Title (e.g. Free ASF Test Kits)"
              className="px-3 py-1.5 rounded-xl border border-stone-300 sm:w-64"
            />
            <input
              type="text"
              value={newDesc}
              onChange={e => setNewDesc(e.target.value)}
              placeholder="Card Description summary..."
              className="px-3 py-1.5 rounded-xl border border-stone-300 flex-1"
            />
            <button
              type="submit"
              className="px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" /> Add Card
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
