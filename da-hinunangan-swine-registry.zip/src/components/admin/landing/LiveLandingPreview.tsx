import React, { useState } from 'react';
import {
  ShieldCheck,
  MapPin,
  Sparkles,
  Phone,
  Mail,
  ExternalLink,
  ArrowRight,
  WifiOff,
  CheckCircle,
  Megaphone,
  ShoppingBag,
  Layers,
  Map,
  FileCheck,
  GraduationCap,
  Users,
  Play,
  Share2,
  Calendar,
  Clock,
  LogIn,
  ChevronRight,
} from 'lucide-react';
import { LandingCmsConfig } from '../../../types/landingCms';
import {
  SealDA,
  SealMunicipality,
  SealTaskForce,
  SealSLSU,
  SealExtension,
} from '../../common/OfficialSeals';

interface LiveLandingPreviewProps {
  config: LandingCmsConfig;
  deviceMode?: 'desktop' | 'tablet' | 'mobile';
  onSelectRole?: (role: string) => void;
  onOpenLogin?: () => void;
}

export const LiveLandingPreview: React.FC<LiveLandingPreviewProps> = ({
  config,
  deviceMode = 'desktop',
  onSelectRole,
  onOpenLogin,
}) => {
  const [activeGalleryCat, setActiveGalleryCat] = useState<string>('all');
  const [selectedGalleryImg, setSelectedGalleryImg] = useState<string | null>(null);

  const theme = config.theme || {
    primaryColor: '#047857',
    secondaryColor: '#064e3b',
    accentColor: '#f59e0b',
    textColor: '#1c1917',
    headingColor: '#064e3b',
    buttonColor: '#047857',
    buttonTextColor: '#ffffff',
    borderRadius: 'large',
  };

  // Helper to render official logo / seal
  const renderLogo = (logo: any) => {
    if (logo.vectorComponent === 'SealMunicipality') return <SealMunicipality className="w-8 h-8 sm:w-9 sm:h-9" />;
    if (logo.vectorComponent === 'SealDA') return <SealDA className="w-8 h-8 sm:w-9 sm:h-9" />;
    if (logo.vectorComponent === 'SealSLSU') return <SealSLSU className="w-8 h-8 sm:w-9 sm:h-9" />;
    if (logo.vectorComponent === 'SealExtension') return <SealExtension className="w-8 h-8 sm:w-9 sm:h-9" />;
    if (logo.vectorComponent === 'SealTaskForce') return <SealTaskForce className="w-8 h-8 sm:w-9 sm:h-9" />;
    if (logo.url) {
      return (
        <img
          src={logo.url}
          alt={logo.name}
          className="w-8 h-8 sm:w-9 sm:h-9 object-contain rounded-full bg-white/20 p-0.5"
          referrerPolicy="no-referrer"
        />
      );
    }
    return <SealDA className="w-8 h-8 sm:w-9 sm:h-9" />;
  };

  const headerLogos = (config.officialLogos || []).filter(
    l => l.visible && (deviceMode !== 'mobile' || l.mobileVisible) && l.placement.startsWith('header')
  );

  const partnerLogos = (config.officialLogos || []).filter(
    l => l.visible && l.placement === 'partners'
  );

  const visibleGallery = (config.galleryPhotos || []).filter(
    p => p.showOnLanding && (activeGalleryCat === 'all' || p.category.toLowerCase().includes(activeGalleryCat.toLowerCase()))
  );

  const containerStyle = {
    fontFamily: theme.bodyFont || 'sans-serif',
    color: theme.textColor || '#1c1917',
  };

  const deviceClass =
    deviceMode === 'mobile'
      ? 'max-w-[390px] mx-auto border-8 border-stone-800 rounded-[40px] shadow-2xl overflow-hidden bg-white my-4'
      : deviceMode === 'tablet'
      ? 'max-w-[768px] mx-auto border-4 border-stone-700 rounded-3xl shadow-xl overflow-hidden bg-white my-4'
      : 'w-full bg-white rounded-2xl shadow-xs overflow-hidden border border-stone-200';

  return (
    <div className={deviceClass} style={containerStyle}>
      {/* Mobile Mock Notch & Status Bar if in mobile mode */}
      {deviceMode === 'mobile' && (
        <div className="bg-stone-900 text-white text-[10px] px-6 py-2 flex items-center justify-between font-semibold select-none">
          <span>9:41</span>
          <div className="w-20 h-4 bg-stone-950 rounded-full mx-auto" />
          <div className="flex items-center gap-1.5">
            <span>5G</span>
            <span>100%</span>
          </div>
        </div>
      )}

      {/* Announcement Bar */}
      {config.announcement?.enabled && (
        <div
          className="px-4 py-2 text-xs font-bold flex items-center justify-center gap-2 text-center shadow-inner transition"
          style={{
            backgroundColor: config.announcement.bgColor || '#f59e0b',
            color: config.announcement.textColor || '#451a03',
          }}
        >
          <Megaphone className="w-4 h-4 shrink-0" />
          <span className="line-clamp-1">{config.announcement.text}</span>
          {config.announcement.linkText && (
            <a
              href={config.announcement.linkUrl || '#'}
              className="underline text-[11px] font-black uppercase tracking-wider ml-1 shrink-0"
            >
              {config.announcement.linkText}
            </a>
          )}
        </div>
      )}

      {/* Main Header / Navigation */}
      <header
        className="px-4 sm:px-6 py-3 border-b flex items-center justify-between sticky top-0 z-20 backdrop-blur-md shadow-xs transition"
        style={{
          backgroundColor: config.headerBgColor || '#064e3b',
          color: config.headerTextColor || '#ffffff',
          borderColor: 'rgba(255, 255, 255, 0.1)',
        }}
      >
        {/* Logos & System Title */}
        <div className="flex items-center gap-3">
          <div className="flex items-center -space-x-1 sm:space-x-1.5">
            {headerLogos.length > 0 ? (
              headerLogos.map(logo => (
                <div key={logo.id} title={logo.name}>
                  {renderLogo(logo)}
                </div>
              ))
            ) : (
              <>
                <SealMunicipality className="w-8 h-8" />
                <SealDA className="w-8 h-8" />
              </>
            )}
          </div>

          <div className="leading-tight">
            <span className="font-black text-xs sm:text-sm tracking-tight block uppercase">
              {config.siteName || 'DA Hinunangan Swine Registry'}
            </span>
            <span className="text-[10px] text-white/80 hidden sm:block truncate max-w-sm">
              {config.siteSubtitle || 'Municipal Agriculture Office • Southern Leyte'}
            </span>
          </div>
        </div>

        {/* Nav Items (Desktop / Tablet) */}
        <div className="hidden lg:flex items-center gap-4 text-xs font-medium text-white/90">
          {(config.navItems || [])
            .filter(n => n.visible)
            .slice(0, 5)
            .map(item => (
              <a
                key={item.id}
                href={item.href}
                className="hover:text-amber-300 transition hover:underline"
              >
                {item.label}
              </a>
            ))}
        </div>

        {/* Header Action Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onOpenLogin?.()}
            className="px-3.5 py-1.5 rounded-xl text-xs font-black shadow-sm transition flex items-center gap-1.5 cursor-pointer hover:opacity-95"
            style={{
              backgroundColor: config.headerButtonColor || '#10b981',
              color: '#064e3b',
            }}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>{config.headerButtonText || 'Sign In'}</span>
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden text-white px-4 sm:px-8 py-10 sm:py-16">
        {/* Background Image & Overlay */}
        <div
          className="absolute inset-0 bg-cover bg-center transition-all duration-300"
          style={{
            backgroundImage: `url(${config.heroBackgroundUrl || config.interfaceBackground?.imageUrl})`,
            backgroundPosition: config.heroBgPosition || 'center',
            backgroundSize: config.heroBgSize || 'cover',
          }}
        />
        <div
          className="absolute inset-0 transition-all duration-300"
          style={{
            backgroundColor: config.heroOverlayColor || '#022c22',
            opacity: (config.heroOverlayOpacity ?? 75) / 100,
          }}
        />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="bg-emerald-800/80 border border-emerald-400/40 text-emerald-200 px-3 py-1 rounded-full text-[11px] font-bold tracking-wide uppercase flex items-center gap-1.5 shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              {config.heroBadgeText || 'Department of Agriculture • Hinunangan, Southern Leyte'}
            </span>
            <span className="bg-teal-900/80 border border-teal-400/40 text-teal-200 px-3 py-1 rounded-full text-[11px] font-bold tracking-wide flex items-center gap-1.5 shadow-sm">
              <WifiOff className="w-3.5 h-3.5" /> 100% Offline Access Ready
            </span>
          </div>

          <h1
            className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight"
            style={{
              textAlign: config.heroTextAlign || 'left',
            }}
          >
            {config.heroTitle}
          </h1>

          <p
            className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed font-normal max-w-2xl"
            style={{
              textAlign: config.heroTextAlign || 'left',
            }}
          >
            {config.heroSubtitle}
          </p>

          <p className="text-[11px] sm:text-xs text-white/75 leading-relaxed max-w-xl">
            {config.heroDescription}
          </p>

          {/* Buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onOpenLogin?.()}
              className="px-5 py-2.5 rounded-xl font-black text-xs shadow-lg transition flex items-center gap-2 cursor-pointer hover:opacity-95"
              style={{
                backgroundColor: theme.accentColor || '#f59e0b',
                color: '#451a03',
              }}
            >
              <LogIn className="w-4 h-4" />
              <span>{config.primaryButtonText || 'Sign In / Login'}</span>
            </button>

            <button
              onClick={() => onSelectRole?.('admin')}
              className="px-4 py-2.5 rounded-xl bg-white text-emerald-950 font-black text-xs shadow-md transition flex items-center gap-2 cursor-pointer hover:bg-emerald-50"
            >
              <span>{config.secondaryButtonText || 'Enter Admin Portal'}</span>
              <ArrowRight className="w-3.5 h-3.5 text-emerald-800" />
            </button>
          </div>
        </div>
      </section>

      {/* Live Impact Counters */}
      <section className="px-4 sm:px-8 py-6 bg-stone-50 border-b border-stone-200">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-4">
            <h2 className="text-sm sm:text-base font-bold text-stone-800 uppercase tracking-wider">
              {config.statsTitle}
            </h2>
            <p className="text-[11px] text-stone-500">{config.statsSubtitle}</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {(config.stats || [])
              .filter(s => s.visible)
              .map(stat => (
                <div
                  key={stat.id}
                  className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs text-center group hover:border-emerald-500 transition"
                >
                  <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider block">
                    {stat.label}
                  </span>
                  <span
                    className="text-2xl sm:text-3xl font-black mt-1 block"
                    style={{ color: theme.primaryColor || '#047857' }}
                  >
                    {stat.value}
                  </span>
                  <span className="text-[10px] text-stone-400 mt-0.5 block">{stat.description}</span>
                </div>
              ))}
          </div>
        </div>
      </section>

      {/* Role-Based Portal Access Cards */}
      <section className="px-4 sm:px-8 py-10 bg-white">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="text-center max-w-xl mx-auto">
            <h2
              className="text-xl sm:text-2xl font-black tracking-tight"
              style={{ color: theme.headingColor || '#064e3b' }}
            >
              Role-Based Citizen & Field Portals
            </h2>
            <p className="text-xs text-stone-500 mt-1">
              Select your accredited access tier to log swine, conduct biosecurity audits, or trade.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Admin */}
            <div className="bg-stone-50 rounded-2xl p-5 border-2 border-stone-200 hover:border-emerald-600 transition flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">1. Municipal Admin (DA MAO)</h3>
                  <p className="text-[11px] text-stone-500 mt-1 leading-relaxed">
                    Full registry control, GIS heatmap, barangay officers, accounts, certificate templates, and broadcast messaging.
                  </p>
                </div>
                <div className="text-[11px] text-stone-600 space-y-1">
                  <p className="flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> Full CRUD on all swine records
                  </p>
                  <p className="flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> Manage 40 Hinunangan barangays
                  </p>
                </div>
              </div>
              <button
                onClick={() => onSelectRole?.('admin')}
                className="mt-5 w-full py-2 rounded-xl text-white font-bold text-xs shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer hover:opacity-95"
                style={{ backgroundColor: theme.primaryColor || '#047857' }}
              >
                <span>Login as Municipal Admin</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Focal Person */}
            <div className="bg-stone-50 rounded-2xl p-5 border-2 border-stone-200 hover:border-blue-600 transition flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">2. Barangay Agricultural Focal</h3>
                  <p className="text-[11px] text-stone-500 mt-1 leading-relaxed">
                    Field officer interface for registering swine in assigned barangay, conducting biosecurity audits, and issuing clearances.
                  </p>
                </div>
                <div className="text-[11px] text-stone-600 space-y-1">
                  <p className="flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-blue-600" /> Offline field registration & queue
                  </p>
                  <p className="flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-blue-600" /> Scoped to designated barangay
                  </p>
                </div>
              </div>
              <button
                onClick={() => onSelectRole?.('focal')}
                className="mt-5 w-full py-2 rounded-xl bg-blue-700 hover:bg-blue-600 text-white font-bold text-xs shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Login as Barangay Focal</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Meat Trader / Agent */}
            <div className="bg-stone-50 rounded-2xl p-5 border-2 border-stone-200 hover:border-amber-600 transition flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                  <ShoppingBag className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">3. Livestock Agent & Meat Trader</h3>
                  <p className="text-[11px] text-stone-500 mt-1 leading-relaxed">
                    Marketplace catalog for commercial buyers to browse verified healthy, market-ready hogs with weights, photos, and direct raiser contacts.
                  </p>
                </div>
                <div className="text-[11px] text-stone-600 space-y-1">
                  <p className="flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-amber-600" /> Ready-to-sell hogs directory
                  </p>
                  <p className="flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-amber-600" /> Direct raiser phone numbers
                  </p>
                </div>
              </div>
              <button
                onClick={() => onSelectRole?.('agent')}
                className="mt-5 w-full py-2 rounded-xl text-amber-950 font-black text-xs shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer hover:opacity-95"
                style={{ backgroundColor: theme.accentColor || '#f59e0b' }}
              >
                <span>Enter Agent Catalog</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="px-4 sm:px-8 py-10 bg-stone-50 border-t border-stone-200">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              <span className="text-[11px] font-bold tracking-wider uppercase text-emerald-800 flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4" /> Academic & Municipal Synergy
              </span>
              <h2
                className="text-xl sm:text-2xl font-black tracking-tight"
                style={{ color: theme.headingColor || '#064e3b' }}
              >
                {config.aboutTitle}
              </h2>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                {config.aboutDescription}
              </p>

              <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(config.aboutCards || [])
                  .filter(c => c.visible)
                  .map(card => (
                    <div key={card.id} className="bg-white p-3.5 rounded-xl border border-stone-200 shadow-2xs">
                      <h4 className="font-bold text-xs text-stone-900 flex items-center gap-1.5">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        {card.title}
                      </h4>
                      <p className="text-[11px] text-stone-500 mt-1 leading-relaxed">{card.description}</p>
                    </div>
                  ))}
              </div>
            </div>

            <div className="relative rounded-2xl overflow-hidden shadow-lg border border-stone-200 aspect-4/3">
              <img
                src={config.aboutImageUrl || 'https://images.unsplash.com/photo-1541888946425-d0fbb186c5f7?auto=format&fit=crop&w=1000&q=80'}
                alt={config.aboutTitle}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent flex items-end p-5">
                <div className="text-white">
                  <p className="text-xs font-bold">SLSU Extension Research & Training</p>
                  <p className="text-[10px] text-stone-300">Empowering 40 Hinunangan Barangays with Science-Based Livestock Management</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="px-4 sm:px-8 py-10 bg-white border-t border-stone-200">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="text-center max-w-xl mx-auto">
            <h2
              className="text-xl sm:text-2xl font-black tracking-tight"
              style={{ color: theme.headingColor || '#064e3b' }}
            >
              {config.featuresTitle}
            </h2>
            <p className="text-xs text-stone-500 mt-1">{config.featuresSubtitle}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {(config.featureCards || [])
              .filter(f => f.visible)
              .map(feat => (
                <div
                  key={feat.id}
                  className="bg-stone-50 rounded-2xl p-4 border border-stone-200 hover:border-emerald-500 hover:shadow-md transition flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                      <Layers className="w-4 h-4" />
                    </div>
                    <h4 className="font-bold text-xs text-stone-900">{feat.title}</h4>
                    <p className="text-[11px] text-stone-500 leading-relaxed">{feat.description}</p>
                  </div>
                  {feat.buttonText && (
                    <div className="pt-3">
                      <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1 hover:underline cursor-pointer">
                        {feat.buttonText} <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  )}
                </div>
              ))}
          </div>
        </div>
      </section>

      {/* Media Photo Gallery */}
      <section className="px-4 sm:px-8 py-10 bg-stone-50 border-t border-stone-200">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
            <div>
              <h2
                className="text-xl sm:text-2xl font-black tracking-tight"
                style={{ color: theme.headingColor || '#064e3b' }}
              >
                {config.galleryTitle}
              </h2>
              <p className="text-xs text-stone-500 mt-1">{config.gallerySubtitle}</p>
            </div>

            {/* Category Filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto text-[11px]">
              {['all', 'Field Operations', 'Biosecurity', 'Training', 'Marketing'].map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveGalleryCat(cat)}
                  className={`px-3 py-1 rounded-full font-bold transition cursor-pointer capitalize ${
                    activeGalleryCat === cat
                      ? 'bg-emerald-800 text-white shadow-2xs'
                      : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Photos Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {visibleGallery.map(photo => (
              <div
                key={photo.id}
                onClick={() => setSelectedGalleryImg(photo.imageUrl)}
                className="group relative rounded-xl overflow-hidden bg-stone-200 aspect-4/3 cursor-pointer shadow-2xs"
              >
                <img
                  src={photo.imageUrl}
                  alt={photo.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition p-3 flex flex-col justify-end text-white text-left">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300">
                    {photo.category}
                  </span>
                  <p className="text-xs font-bold leading-tight mt-0.5">{photo.title}</p>
                  <p className="text-[10px] text-stone-300 line-clamp-1">{photo.caption}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Social Posts & Advisories */}
      <section className="px-4 sm:px-8 py-10 bg-white border-t border-stone-200">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="text-center max-w-xl mx-auto">
            <h2
              className="text-xl sm:text-2xl font-black tracking-tight"
              style={{ color: theme.headingColor || '#064e3b' }}
            >
              {config.socialTitle}
            </h2>
            <p className="text-xs text-stone-500 mt-1">{config.socialSubtitle}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {(config.socialPosts || [])
              .filter(p => p.visible)
              .map(post => (
                <div
                  key={post.id}
                  className="bg-stone-50 rounded-2xl p-4 border border-stone-200 flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-[11px] text-stone-400">
                      <span className="font-bold text-emerald-800 flex items-center gap-1">
                        <Share2 className="w-3 h-3" /> {post.author}
                      </span>
                      <span>{post.date}</span>
                    </div>
                    <h4 className="font-bold text-xs text-stone-900 leading-snug">{post.title}</h4>
                    <p className="text-[11px] text-stone-600 leading-relaxed">{post.content}</p>
                  </div>

                  <div className="pt-3 border-t border-stone-200/60 mt-3 flex items-center justify-between gap-2">
                    <span className="text-[10px] text-stone-400 truncate">
                      {post.noticeLabel || 'Official Municipal Notice'}
                    </span>
                    <a
                      href={post.postUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[11px] font-bold text-blue-700 hover:underline flex items-center gap-1 shrink-0"
                    >
                      <span>{post.buttonText || 'View on Facebook'}</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </section>

      {/* Official Partners & Institutional Emblems */}
      <section className="px-4 sm:px-8 py-8 bg-stone-50 border-t border-stone-200">
        <div className="max-w-6xl mx-auto text-center space-y-4">
          <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500 block">
            Cooperating Agencies & Academic Partners
          </span>
          <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10">
            {partnerLogos.map(logo => (
              <div key={logo.id} className="flex items-center gap-2 group" title={logo.name}>
                {renderLogo(logo)}
                <div className="text-left text-[11px]">
                  <p className="font-bold text-stone-800 leading-tight">{logo.institution}</p>
                  <p className="text-[10px] text-stone-500">{logo.name}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact & Hotlines */}
      <section className="px-4 sm:px-8 py-8 bg-emerald-50 border-t border-emerald-200">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 flex items-center justify-center md:justify-start gap-1.5">
              <Phone className="w-3.5 h-3.5" /> 24/7 Livestock & ASF Emergency Support
            </span>
            <h3 className="text-lg font-black text-emerald-950">{config.officeName}</h3>
            <p className="text-xs text-emerald-900/80">{config.address}</p>
            <p className="text-[11px] text-emerald-800 font-medium">{config.officeHours}</p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <a
              href={`tel:${config.hotlineEmergency}`}
              className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs flex items-center gap-1.5 shadow-sm transition"
            >
              <Phone className="w-3.5 h-3.5" /> ASF Hotline: {config.hotlineEmergency}
            </a>
            <a
              href={`mailto:${config.contactEmail}`}
              className="px-4 py-2.5 rounded-xl bg-white hover:bg-emerald-50 text-emerald-950 border border-emerald-300 font-bold text-xs flex items-center gap-1.5 shadow-2xs transition"
            >
              <Mail className="w-3.5 h-3.5 text-emerald-700" /> {config.contactEmail}
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 sm:px-8 py-10 bg-stone-900 text-stone-300 text-xs border-t border-stone-800">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Col 1: System info & Seals */}
            <div className="space-y-3 md:col-span-1">
              <div className="flex items-center gap-2">
                <SealMunicipality className="w-7 h-7" />
                <SealDA className="w-7 h-7" />
                <span className="font-bold text-white text-sm">DA Hinunangan</span>
              </div>
              <p className="text-[11px] text-stone-400 leading-relaxed">
                {config.footerDescription}
              </p>
            </div>

            {/* Configured Columns */}
            {(config.footerColumns || []).slice(0, 3).map(col => (
              <div key={col.id} className="space-y-2">
                <h5 className="font-bold text-white text-xs uppercase tracking-wider">
                  {col.title}
                </h5>
                <ul className="space-y-1.5 text-[11px] text-stone-400">
                  {col.links.map(link => (
                    <li key={link.id}>
                      <a
                        href={link.url}
                        target={link.external ? '_blank' : undefined}
                        rel={link.external ? 'noopener noreferrer' : undefined}
                        className="hover:text-emerald-400 transition"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="pt-6 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-[10px] text-stone-500">
            <p>{config.footerCopyright}</p>
            <p>Republic of the Philippines • Department of Agriculture Region VIII</p>
          </div>
        </div>
      </footer>

      {/* Lightbox Preview Modal */}
      {selectedGalleryImg && (
        <div
          onClick={() => setSelectedGalleryImg(null)}
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 cursor-pointer"
        >
          <div className="max-w-2xl w-full bg-white rounded-2xl overflow-hidden shadow-2xl" onClick={e => e.stopPropagation()}>
            <img
              src={selectedGalleryImg}
              alt="Gallery preview"
              className="w-full max-h-[70vh] object-contain bg-black"
            />
            <div className="p-4 flex items-center justify-between text-xs">
              <span className="font-bold text-stone-900">Gallery Preview</span>
              <button
                onClick={() => setSelectedGalleryImg(null)}
                className="px-3 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 font-bold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
