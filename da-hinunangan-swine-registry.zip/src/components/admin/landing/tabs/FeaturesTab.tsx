import React, { useState } from 'react';
import { Layers, Plus, Trash2, ArrowUp, ArrowDown, Eye, EyeOff } from 'lucide-react';
import { FeatureCardItem, LandingCmsConfig } from '../../../../types/landingCms';

interface FeaturesTabProps {
  config: LandingCmsConfig;
  onChange: (updates: Partial<LandingCmsConfig>) => void;
}

export const FeaturesTab: React.FC<FeaturesTabProps> = ({ config, onChange }) => {
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newBtnText, setNewBtnText] = useState('');
  const [newBtnLink, setNewBtnLink] = useState('#');

  const featureCards = config.featureCards || [];

  const handleToggleVisible = (id: string) => {
    onChange({
      featureCards: featureCards.map(f => (f.id === id ? { ...f, visible: !f.visible } : f)),
    });
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const newIdx = direction === 'up' ? index - 1 : index + 1;
    if (newIdx < 0 || newIdx >= featureCards.length) return;
    const clone = [...featureCards];
    const temp = clone[index];
    clone[index] = clone[newIdx];
    clone[newIdx] = temp;
    onChange({ featureCards: clone.map((f, i) => ({ ...f, order: i + 1 })) });
  };

  const handleDelete = (id: string) => {
    onChange({ featureCards: featureCards.filter(f => f.id !== id) });
  };

  const handleUpdateCard = (id: string, updates: Partial<FeatureCardItem>) => {
    onChange({
      featureCards: featureCards.map(f => (f.id === id ? { ...f, ...updates } : f)),
    });
  };

  const handleAddFeature = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const newFeat: FeatureCardItem = {
      id: 'feat-' + Date.now(),
      title: newTitle.trim(),
      description: newDesc.trim(),
      icon: 'Layers',
      buttonText: newBtnText.trim() || undefined,
      buttonLink: newBtnLink.trim() || undefined,
      visible: true,
      order: featureCards.length + 1,
    };
    onChange({ featureCards: [...featureCards, newFeat] });
    setNewTitle('');
    setNewDesc('');
    setNewBtnText('');
    setNewBtnLink('#');
  };

  return (
    <div className="space-y-6 text-xs text-stone-800">
      {/* Section Headlines */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 border-b pb-3 border-stone-100">
          <Layers className="w-4 h-4 text-emerald-700" />
          <h3 className="font-bold text-stone-900 text-sm">Features Section Headlines</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold text-stone-700 mb-1">Section Title</label>
            <input
              type="text"
              value={config.featuresTitle}
              onChange={e => onChange({ featuresTitle: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-stone-300 font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
            />
          </div>
          <div>
            <label className="block font-semibold text-stone-700 mb-1">Section Subtitle</label>
            <input
              type="text"
              value={config.featuresSubtitle}
              onChange={e => onChange({ featuresSubtitle: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
            />
          </div>
        </div>
      </div>

      {/* Feature Cards Manager */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b pb-3 border-stone-100">
          <h3 className="font-bold text-stone-900 text-sm">System Capabilities & Modules Cards</h3>
          <span className="text-[11px] text-stone-400">{featureCards.length} Cards</span>
        </div>

        <div className="space-y-3">
          {featureCards.map((card, idx) => (
            <div
              key={card.id}
              className={`p-4 rounded-xl border space-y-2.5 transition ${
                card.visible ? 'bg-stone-50 border-stone-200' : 'bg-stone-100/60 border-stone-200 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <span className="font-mono text-stone-400 text-[11px]">#{idx + 1}</span>
                <input
                  type="text"
                  value={card.title}
                  onChange={e => handleUpdateCard(card.id, { title: e.target.value })}
                  className="flex-1 px-2.5 py-1 rounded-lg border border-stone-300 bg-white font-bold text-stone-900 text-xs"
                />
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleToggleVisible(card.id)}
                    className="p-1 rounded-md hover:bg-stone-200 text-stone-600 cursor-pointer"
                  >
                    {card.visible ? <Eye className="w-3.5 h-3.5 text-emerald-700" /> : <EyeOff className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    type="button"
                    disabled={idx === 0}
                    onClick={() => handleMove(idx, 'up')}
                    className="p-1 rounded-md hover:bg-stone-200 text-stone-600 disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    disabled={idx === featureCards.length - 1}
                    onClick={() => handleMove(idx, 'down')}
                    className="p-1 rounded-md hover:bg-stone-200 text-stone-600 disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(card.id)}
                    className="p-1 rounded-md hover:bg-red-50 text-red-600 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <textarea
                rows={2}
                value={card.description}
                onChange={e => handleUpdateCard(card.id, { description: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 bg-white text-[11px] leading-relaxed"
                placeholder="Detailed feature description"
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <input
                  type="text"
                  value={card.buttonText || ''}
                  onChange={e => handleUpdateCard(card.id, { buttonText: e.target.value })}
                  placeholder="Button label (e.g. View Map)"
                  className="px-2.5 py-1 rounded-lg border border-stone-300 bg-white text-[11px]"
                />
                <input
                  type="text"
                  value={card.buttonLink || ''}
                  onChange={e => handleUpdateCard(card.id, { buttonLink: e.target.value })}
                  placeholder="Target link (e.g. #gis)"
                  className="px-2.5 py-1 rounded-lg border border-stone-300 bg-white font-mono text-[11px]"
                />
              </div>
            </div>
          ))}
        </div>

        {/* Add Feature Form */}
        <form onSubmit={handleAddFeature} className="pt-3 border-t border-stone-100 space-y-2">
          <span className="font-semibold text-stone-700 block text-xs">Add New Feature Card</span>
          <div className="space-y-2">
            <input
              type="text"
              value={newTitle}
              onChange={e => setNewTitle(e.target.value)}
              placeholder="Feature Title (e.g. Solar Ear Tag Tracing)"
              className="w-full px-3 py-1.5 rounded-xl border border-stone-300"
            />
            <textarea
              rows={2}
              value={newDesc}
              onChange={e => setNewDesc(e.target.value)}
              placeholder="Brief description of feature..."
              className="w-full px-3 py-1.5 rounded-xl border border-stone-300"
            />
            <div className="flex flex-wrap gap-2">
              <input
                type="text"
                value={newBtnText}
                onChange={e => setNewBtnText(e.target.value)}
                placeholder="Button text (optional)"
                className="px-3 py-1.5 rounded-xl border border-stone-300 w-44"
              />
              <input
                type="text"
                value={newBtnLink}
                onChange={e => setNewBtnLink(e.target.value)}
                placeholder="Target URL / anchor"
                className="px-3 py-1.5 rounded-xl border border-stone-300 flex-1 font-mono text-[11px]"
              />
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add Feature
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
