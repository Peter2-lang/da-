import React, { useState } from 'react';
import { Video, Plus, Trash2, Eye, EyeOff, Play, ExternalLink } from 'lucide-react';
import { LandingCmsConfig, VideoItem } from '../../../../types/landingCms';

interface VideoMediaTabProps {
  config: LandingCmsConfig;
  onChange: (updates: Partial<LandingCmsConfig>) => void;
  onOpenMediaPicker?: (targetField: string) => void;
}

export const VideoMediaTab: React.FC<VideoMediaTabProps> = ({
  config,
  onChange,
  onOpenMediaPicker,
}) => {
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newThumb, setNewThumb] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const videos = config.videos || [];

  const handleToggleVisible = (id: string) => {
    const updated = videos.map(v => (v.id === id ? { ...v, visible: !v.visible } : v));
    onChange({ videos: updated });
  };

  const handleDelete = (id: string) => {
    onChange({ videos: videos.filter(v => v.id !== id) });
  };

  const handleUpdate = (id: string, updates: Partial<VideoItem>) => {
    const updated = videos.map(v => (v.id === id ? { ...v, ...updates } : v));
    onChange({ videos: updated });
  };

  const handleAddVideo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newUrl.trim()) return;
    const item: VideoItem = {
      id: 'vid-' + Date.now(),
      title: newTitle.trim(),
      description: newDesc.trim(),
      videoUrl: newUrl.trim(),
      thumbnailUrl: newThumb.trim() || 'https://images.unsplash.com/photo-1541888946425-d0fbb186c5f7?auto=format&fit=crop&w=1000&q=80',
      visible: true,
      order: videos.length + 1,
    };
    onChange({ videos: [...videos, item] });
    setNewTitle('');
    setNewUrl('');
    setNewThumb('');
    setNewDesc('');
  };

  return (
    <div className="space-y-6 text-xs text-stone-800">
      {/* Headlines */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 border-b pb-3 border-stone-100">
          <Video className="w-4 h-4 text-emerald-700" />
          <h3 className="font-bold text-stone-900 text-sm">Educational Video Section Headlines</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold text-stone-700 mb-1">Section Title</label>
            <input
              type="text"
              value={config.videosTitle}
              onChange={e => onChange({ videosTitle: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-stone-300 font-bold text-stone-900"
            />
          </div>
          <div>
            <label className="block font-semibold text-stone-700 mb-1">Section Subtitle</label>
            <input
              type="text"
              value={config.videosSubtitle}
              onChange={e => onChange({ videosSubtitle: e.target.value })}
              className="w-full px-3 py-2 rounded-xl border border-stone-300"
            />
          </div>
        </div>
      </div>

      {/* Videos List */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b pb-3 border-stone-100">
          <h3 className="font-bold text-stone-900 text-sm">Educational & Extension Videos</h3>
          <span className="text-[11px] text-stone-400">{videos.length} Videos</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {videos.map(video => (
            <div
              key={video.id}
              className={`rounded-2xl border overflow-hidden flex flex-col justify-between transition ${
                video.visible ? 'bg-stone-50 border-stone-200' : 'bg-stone-100/60 border-stone-200 opacity-60'
              }`}
            >
              <div className="relative aspect-video bg-stone-900 flex items-center justify-center">
                {video.thumbnailUrl ? (
                  <img
                    src={video.thumbnailUrl}
                    alt={video.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center text-white">
                    <Play className="w-6 h-6 fill-white" />
                  </div>
                )}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <div className="w-10 h-10 rounded-full bg-emerald-600/90 text-white flex items-center justify-center shadow-lg">
                    <Play className="w-5 h-5 fill-white ml-0.5" />
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleVisible(video.id)}
                  className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/70 text-white hover:bg-black cursor-pointer"
                >
                  {video.visible ? <Eye className="w-3.5 h-3.5 text-emerald-400" /> : <EyeOff className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="p-3.5 space-y-2 flex-1">
                <input
                  type="text"
                  value={video.title}
                  onChange={e => handleUpdate(video.id, { title: e.target.value })}
                  className="w-full px-2.5 py-1 rounded-lg border border-stone-300 bg-white font-bold text-xs"
                />
                <textarea
                  rows={2}
                  value={video.description}
                  onChange={e => handleUpdate(video.id, { description: e.target.value })}
                  className="w-full px-2.5 py-1 rounded-lg border border-stone-300 bg-white text-[11px]"
                />
                <div className="flex items-center justify-between pt-1">
                  <a
                    href={video.videoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-emerald-700 font-bold hover:underline flex items-center gap-1 text-[11px]"
                  >
                    Watch Video <ExternalLink className="w-3 h-3" />
                  </a>
                  <button
                    type="button"
                    onClick={() => handleDelete(video.id)}
                    className="p-1.5 rounded-lg hover:bg-red-50 text-red-600 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Add Video Form */}
        <form onSubmit={handleAddVideo} className="pt-4 border-t border-stone-100 space-y-2">
          <span className="font-semibold text-stone-700 block text-xs">Add New Video Guide</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input
              type="text"
              value={newTitle}
              onChange={e => setNewTitle(e.target.value)}
              placeholder="Video Title (e.g. Disinfection Protocol Guide)"
              className="px-3 py-1.5 rounded-xl border border-stone-300"
            />
            <input
              type="text"
              value={newUrl}
              onChange={e => setNewUrl(e.target.value)}
              placeholder="YouTube URL or MP4 Link"
              className="px-3 py-1.5 rounded-xl border border-stone-300 font-mono text-[11px]"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input
              type="text"
              value={newThumb}
              onChange={e => setNewThumb(e.target.value)}
              placeholder="Thumbnail Image URL (optional)"
              className="px-3 py-1.5 rounded-xl border border-stone-300 font-mono text-[11px]"
            />
            <input
              type="text"
              value={newDesc}
              onChange={e => setNewDesc(e.target.value)}
              placeholder="Brief summary of video contents..."
              className="px-3 py-1.5 rounded-xl border border-stone-300"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> Add Video
          </button>
        </form>
      </div>
    </div>
  );
};
