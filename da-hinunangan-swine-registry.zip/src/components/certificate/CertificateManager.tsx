import React, { useState, useMemo } from 'react';
import {
  FileText,
  Printer,
  Edit,
  Save,
  Plus,
  Trash2,
  Image as ImageIcon,
  CheckCircle,
  ShieldCheck,
  Building,
  UserCheck,
  Sparkles,
  ArrowRight,
  Upload,
  Download,
  X,
  Eye,
  RefreshCw,
  Search,
  Filter,
  CheckSquare,
} from 'lucide-react';
import { CertificateConfig, CertificateSignatory, IssuedCertificate, SwineRecord, UserAccount } from '../../types';
import { storageService } from '../../services/storageService';
import { SealDA, SealMunicipality, SealTaskForce, SealSLSU } from '../common/OfficialSeals';

interface CertificateManagerProps {
  swineList: SwineRecord[];
  currentUser: UserAccount | null;
  selectedSwineInitial?: SwineRecord | null;
}

export const CertificateManager: React.FC<CertificateManagerProps> = ({
  swineList,
  currentUser,
  selectedSwineInitial,
}) => {
  const [activeTab, setActiveTab] = useState<'issue' | 'customize' | 'history'>('issue');
  const [config, setConfig] = useState<CertificateConfig>(() => storageService.getCertificateConfig());
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [pdfToast, setPdfToast] = useState(false);

  // Certificate Type Selector (Exact match to prompt requirement)
  const [certificateType, setCertificateType] = useState<string>('Maked Certificate');

  // Farmer filter & Swine selection
  const uniqueFarmers = useMemo(() => {
    const map = new Map<string, string>();
    swineList.forEach(s => {
      if (s.farmerName && !map.has(s.farmerName)) {
        map.set(s.farmerName, s.barangay);
      }
    });
    return Array.from(map.entries()).map(([farmerName, barangay]) => ({ farmerName, barangay }));
  }, [swineList]);

  const [selectedFarmer, setSelectedFarmer] = useState<string>(
    selectedSwineInitial?.farmerName || uniqueFarmers[0]?.farmerName || ''
  );

  // Filter swine for the selected farmer
  const farmerSwineList = useMemo(() => {
    if (!selectedFarmer) return swineList;
    return swineList.filter(s => s.farmerName.toLowerCase() === selectedFarmer.toLowerCase());
  }, [swineList, selectedFarmer]);

  // Selected Swine for issuance
  const [selectedSwineId, setSelectedSwineId] = useState<string>(
    selectedSwineInitial?.id || farmerSwineList[0]?.id || swineList[0]?.id || ''
  );

  const selectedSwine = swineList.find(s => s.id === selectedSwineId) || farmerSwineList[0] || swineList[0];

  // Issue details
  const [buyerName, setBuyerName] = useState('Juan C. Mercado (Licensed Meat Trader)');
  const [destinationBarangay, setDestinationBarangay] = useState('Hinunangan Municipal Slaughterhouse');
  const [destinationMunicipality, setDestinationMunicipality] = useState('Hinunangan, Southern Leyte');
  const [inspectionResult, setInspectionResult] = useState('Healthy, No fever/lesions, Green Zone compliant');
  const [issuedControlNo, setIssuedControlNo] = useState(
    `CERT-HN-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`
  );

  // Template Customization state
  const [centerLogoUrl, setCenterLogoUrl] = useState(config.centerLogoUrl || '/icon.svg');
  const [authorizedPerson, setAuthorizedPerson] = useState(config.authorizedPerson);
  const [authorizedPersonTitle, setAuthorizedPersonTitle] = useState(config.authorizedPersonTitle);
  const [letterBodyTemplate, setLetterBodyTemplate] = useState(config.letterBodyTemplate);
  const [signatories, setSignatories] = useState<CertificateSignatory[]>(config.signatories || []);

  // New signatory inputs
  const [newSigName, setNewSigName] = useState('');
  const [newSigTitle, setNewSigTitle] = useState('');
  const [newSigOffice, setNewSigOffice] = useState('');

  // Handle Farmer change
  const handleFarmerChange = (farmer: string) => {
    setSelectedFarmer(farmer);
    const matching = swineList.filter(s => s.farmerName.toLowerCase() === farmer.toLowerCase());
    if (matching.length > 0) {
      setSelectedSwineId(matching[0].id);
    }
  };

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedConfig: CertificateConfig = {
      ...config,
      centerLogoUrl,
      authorizedPerson,
      authorizedPersonTitle,
      letterBodyTemplate,
      signatories,
    };
    storageService.saveCertificateConfig(updatedConfig);
    setConfig(updatedConfig);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleAddSignatory = () => {
    if (!newSigName.trim() || !newSigTitle.trim()) {
      alert('Please fill in name and title for the signatory.');
      return;
    }
    const newSig: CertificateSignatory = {
      id: 'sig-' + Date.now(),
      name: newSigName.toUpperCase(),
      title: newSigTitle,
      office: newSigOffice || 'Local Government Unit',
      order: signatories.length + 1,
    };
    setSignatories([...signatories, newSig]);
    setNewSigName('');
    setNewSigTitle('');
    setNewSigOffice('');
  };

  const handleRemoveSignatory = (id: string) => {
    setSignatories(signatories.filter(s => s.id !== id));
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCenterLogoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePrint = () => {
    if (selectedSwine) {
      const cert: IssuedCertificate = {
        certificateNo: issuedControlNo,
        swineId: selectedSwine.id,
        earTagNo: selectedSwine.earTagNo,
        farmerName: selectedSwine.farmerName,
        buyerName,
        destinationBarangay,
        destinationMunicipality,
        issueDate: new Date().toISOString(),
        validUntil: new Date(Date.now() + 72 * 3600 * 1000).toISOString(),
        authorizedBy: authorizedPerson,
        status: 'active',
        qrVerificationCode: `DA-HN-${selectedSwine.earTagNo}-${issuedControlNo}`,
      };
      storageService.issueCertificate(cert);
    }
    window.print();
  };

  const handleSaveAsPdf = () => {
    if (selectedSwine) {
      const cert: IssuedCertificate = {
        certificateNo: issuedControlNo,
        swineId: selectedSwine.id,
        earTagNo: selectedSwine.earTagNo,
        farmerName: selectedSwine.farmerName,
        buyerName,
        destinationBarangay,
        destinationMunicipality,
        issueDate: new Date().toISOString(),
        validUntil: new Date(Date.now() + 72 * 3600 * 1000).toISOString(),
        authorizedBy: authorizedPerson,
        status: 'active',
        qrVerificationCode: `DA-HN-${selectedSwine.earTagNo}-${issuedControlNo}`,
      };
      storageService.issueCertificate(cert);
    }
    setPdfToast(true);
    setTimeout(() => {
      setPdfToast(false);
      window.print();
    }, 800);
  };

  const handleResetForm = () => {
    setIssuedControlNo(`CERT-HN-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
    setBuyerName('Juan C. Mercado (Licensed Meat Trader)');
    setDestinationBarangay('Hinunangan Municipal Slaughterhouse');
    setDestinationMunicipality('Hinunangan, Southern Leyte');
    setCertificateType('Maked Certificate');
  };

  // Certificate title based on selection
  const activeCertificateTitle = useMemo(() => {
    if (certificateType === 'Maked Certificate') return 'OFFICIAL BARANGAY LIVESTOCK BIOSECURITY CLEARANCE & TRANSFER PERMIT';
    if (certificateType === 'New Certificate') return 'OFFICIAL SWINE REGISTRATION & HEALTH INSPECTION CERTIFICATE';
    if (certificateType === 'Barangay Livestock Clearance') return 'BARANGAY LIVESTOCK CLEARANCE & ORIGIN PERMIT';
    if (certificateType === 'Swine Biosecurity Certificate') return 'SWINE BIOSECURITY INSPECTION & ASF-FREE CLEARANCE';
    if (certificateType === 'Livestock Transfer & Movement Permit') return 'MUNICIPAL LIVESTOCK TRANSFER & SLAUGHTER PERMIT';
    return config.certificateTitle || 'OFFICIAL LIVESTOCK BIOSECURITY CLEARANCE';
  }, [certificateType, config.certificateTitle]);

  return (
    <div className="max-w-6xl mx-auto py-6 px-4 space-y-6">
      {/* Top Banner & Control Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-700" />
            <h2 className="text-xl font-bold text-stone-900">Certificate Management</h2>
          </div>
          <p className="text-xs text-stone-500 mt-0.5">
            Issue official certification for swine transfer/selling, customize letter text, authorized official, and center seal logo.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex rounded-xl bg-stone-100 p-1 border border-stone-200 text-xs">
            <button
              onClick={() => setActiveTab('issue')}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                activeTab === 'issue' ? 'bg-emerald-700 text-white shadow-2xs' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Issue & Print
            </button>
            <button
              onClick={() => setActiveTab('customize')}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1 ${
                activeTab === 'customize' ? 'bg-emerald-700 text-white shadow-2xs' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Edit className="w-3.5 h-3.5" /> Customize Template
            </button>
          </div>

          {activeTab === 'issue' && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrint}
                className="bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 shadow-sm transition cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print</span>
              </button>
              <button
                type="button"
                onClick={handleSaveAsPdf}
                className="bg-blue-700 hover:bg-blue-600 text-white text-xs font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 shadow-sm transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Save as PDF</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {pdfToast && (
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-xs font-semibold flex items-center justify-between shadow-sm animate-pulse">
          <div className="flex items-center gap-2">
            <Download className="w-4 h-4 text-blue-700" />
            <span>Generating high-resolution official PDF document and opening print/save dialog...</span>
          </div>
          <span className="font-mono text-[11px] text-blue-600">PDF Ready</span>
        </div>
      )}

      {activeTab === 'customize' ? (
        /* ----------------- TEMPLATE CUSTOMIZER TAB ----------------- */
        <form onSubmit={handleSaveConfig} className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-5 text-xs">
            <div className="flex items-center justify-between border-b pb-3 border-stone-100">
              <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-emerald-700" /> 1. Center Logo & Municipal Seals
              </h3>
              {saveSuccess && (
                <span className="text-emerald-700 font-bold flex items-center gap-1 text-xs">
                  <CheckCircle className="w-4 h-4" /> Template Saved Successfully!
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Center Logo Image URL / Upload
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={centerLogoUrl}
                    onChange={e => setCenterLogoUrl(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-lg border border-stone-300 font-mono text-[11px]"
                  />
                  <label className="bg-stone-100 hover:bg-stone-200 px-3 py-2 rounded-lg border border-stone-300 font-semibold text-stone-700 cursor-pointer flex items-center gap-1">
                    <Upload className="w-3.5 h-3.5" /> Upload
                    <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                  </label>
                </div>
                <p className="text-[11px] text-stone-500 mt-1">
                  This logo will appear as a prominent centered emblem on the official certificate.
                </p>
              </div>

              <div className="flex items-center gap-4 bg-stone-50 p-3 rounded-xl border border-stone-200">
                <div className="w-16 h-16 rounded-lg border border-stone-300 bg-white flex items-center justify-center p-1 shrink-0 overflow-hidden">
                  <img src={centerLogoUrl} alt="Center Logo Preview" className="w-full h-full object-contain" />
                </div>
                <div>
                  <span className="font-bold text-stone-800 block text-xs">Center Seal Preview</span>
                  <span className="text-[11px] text-stone-500">Official Municipal / DA Seal</span>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Authorized Official & Letter Body */}
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-5 text-xs">
            <h3 className="font-bold text-stone-900 text-sm border-b pb-3 border-stone-100 flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-emerald-700" /> 2. Authorized Official & Certification Letter Body
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Authorized Signatory Official Name
                </label>
                <input
                  type="text"
                  value={authorizedPerson}
                  onChange={e => setAuthorizedPerson(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 font-bold"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Official Position / Title</label>
                <input
                  type="text"
                  value={authorizedPersonTitle}
                  onChange={e => setAuthorizedPersonTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Certificate Letter Text & Statement
              </label>
              <textarea
                rows={6}
                value={letterBodyTemplate}
                onChange={e => setLetterBodyTemplate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-stone-300 font-sans text-xs leading-relaxed"
              />
              <p className="text-[11px] text-stone-500 mt-1">
                You can freely customize the wording of the biosecurity clearance and transport permit.
              </p>
            </div>
          </div>

          {/* Section 3: Add / Edit Persons Who Need Signature */}
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4 text-xs">
            <h3 className="font-bold text-stone-900 text-sm border-b pb-3 border-stone-100 flex items-center gap-2">
              <Edit className="w-4 h-4 text-emerald-700" /> 3. Certificate Signatories & Signature Blocks
            </h3>

            <p className="text-stone-500">
              Add or remove authorized persons whose signatures are required on the issued document:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {signatories.map((sig, idx) => (
                <div
                  key={sig.id}
                  className="p-3 rounded-xl border border-stone-200 bg-stone-50 relative group"
                >
                  <button
                    type="button"
                    onClick={() => handleRemoveSignatory(sig.id)}
                    className="absolute top-2 right-2 text-stone-400 hover:text-red-600 p-1 cursor-pointer"
                    title="Remove Signatory"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-[10px] text-emerald-700 font-bold uppercase">Signatory #{idx + 1}</span>
                  <p className="font-bold text-stone-900 mt-1">{sig.name}</p>
                  <p className="text-[11px] text-stone-600">{sig.title}</p>
                  <p className="text-[10px] text-stone-400">{sig.office}</p>
                </div>
              ))}
            </div>

            {/* Add New Signatory Row */}
            <div className="bg-emerald-50/50 p-4 rounded-xl border border-emerald-200 space-y-3">
              <span className="font-bold text-emerald-950 block text-xs">Add New Signatory Person</span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="Full Name (e.g. HON. PEDRO C. BALAGAO)"
                  value={newSigName}
                  onChange={e => setNewSigName(e.target.value)}
                  className="px-3 py-1.5 rounded-lg border border-stone-300 bg-white"
                />
                <input
                  type="text"
                  placeholder="Title / Designation (e.g. Punong Barangay)"
                  value={newSigTitle}
                  onChange={e => setNewSigTitle(e.target.value)}
                  className="px-3 py-1.5 rounded-lg border border-stone-300 bg-white"
                />
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Office / Agency"
                    value={newSigOffice}
                    onChange={e => setNewSigOffice(e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded-lg border border-stone-300 bg-white"
                  />
                  <button
                    type="button"
                    onClick={handleAddSignatory}
                    className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow-md flex items-center gap-2 cursor-pointer transition"
            >
              <Save className="w-4 h-4" /> Save Certificate Template
            </button>
          </div>
        </form>
      ) : (
        /* ----------------- ISSUE & PREVIEW TAB ----------------- */
        <div className="space-y-6">
          {/* Certificate Selection Box as strictly requested */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b pb-3 border-stone-100">
              <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-700" /> Certificate Management & Parameters
              </h3>
              <span className="text-[11px] bg-emerald-50 text-emerald-800 font-semibold px-2.5 py-0.5 rounded-full border border-emerald-200">
                Mode: {certificateType || 'Select Certificate'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              {/* 1. Certificate Type Dropdown */}
              <div>
                <label className="block font-bold text-stone-800 mb-1.5">
                  Certificate Type
                </label>
                <div className="relative">
                  <select
                    id="certificate-type-select"
                    value={certificateType}
                    onChange={e => setCertificateType(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border-2 border-emerald-600 font-bold text-emerald-950 bg-emerald-50/40 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden cursor-pointer shadow-xs"
                  >
                    <option value="">Select Certificate</option>
                    <option value="Maked Certificate">Maked Certificate</option>
                    <option value="New Certificate">New Certificate</option>
                    <option value="Barangay Livestock Clearance">Barangay Livestock Clearance</option>
                    <option value="Swine Biosecurity Certificate">Swine Biosecurity Certificate</option>
                    <option value="Livestock Transfer & Movement Permit">Livestock Transfer & Movement Permit</option>
                  </select>
                </div>
                <p className="text-[10px] text-stone-500 mt-1">
                  Choose certificate template mode to populate fields and layout.
                </p>
              </div>

              {/* 2. Farmer Selector */}
              <div>
                <label className="block font-bold text-stone-800 mb-1.5">
                  Select Farmer / Hog Raiser
                </label>
                <select
                  value={selectedFarmer}
                  onChange={e => handleFarmerChange(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-stone-300 font-medium bg-white focus:ring-2 focus:ring-emerald-600 focus:outline-hidden cursor-pointer"
                >
                  {uniqueFarmers.map(f => (
                    <option key={f.farmerName} value={f.farmerName}>
                      {f.farmerName} (Brgy. {f.barangay})
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-stone-500 mt-1">
                  Filters available registered swine under this farmer.
                </p>
              </div>

              {/* 3. Swine / Ear Tag Selector */}
              <div>
                <label className="block font-bold text-stone-800 mb-1.5">
                  Select Swine / Registry Record
                </label>
                <select
                  value={selectedSwineId}
                  onChange={e => setSelectedSwineId(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-stone-300 font-mono font-bold bg-white text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-hidden cursor-pointer"
                >
                  {farmerSwineList.map(s => (
                    <option key={s.id} value={s.id}>
                      Tag: {s.earTagNo} • {s.breed} ({s.weightKg}kg)
                    </option>
                  ))}
                  {farmerSwineList.length === 0 && swineList.map(s => (
                    <option key={s.id} value={s.id}>
                      Tag: {s.earTagNo} - {s.farmerName} ({s.weightKg}kg)
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-stone-500 mt-1">
                  Verified Ear Tag and biosecurity record.
                </p>
              </div>
            </div>

            {/* Additional Issuance Details */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs pt-2 border-t border-stone-100">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">Buyer / Meat Trader / Transferee</label>
                <input
                  type="text"
                  value={buyerName}
                  onChange={e => setBuyerName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                  placeholder="e.g. Licensed Trader Name"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Destination Facility / Slaughterhouse</label>
                <input
                  type="text"
                  value={destinationBarangay}
                  onChange={e => setDestinationBarangay(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                  placeholder="e.g. Municipal Slaughterhouse"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Destination Municipality & Province</label>
                <input
                  type="text"
                  value={destinationMunicipality}
                  onChange={e => setDestinationMunicipality(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                  placeholder="e.g. Hinunangan, Southern Leyte"
                />
              </div>
            </div>

            {/* Action Buttons: Print, Save as PDF, Cancel */}
            <div className="flex flex-wrap items-center justify-between pt-3 border-t border-stone-100 gap-3">
              <div className="flex items-center gap-2 text-xs text-stone-600 font-mono">
                <span>CONTROL NO:</span>
                <span className="font-bold text-emerald-950 bg-stone-100 px-2 py-0.5 rounded border border-stone-200">
                  {issuedControlNo}
                </span>
                <button
                  type="button"
                  onClick={() => setIssuedControlNo(`CERT-HN-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`)}
                  className="text-stone-400 hover:text-stone-700 p-1 cursor-pointer"
                  title="Generate New Control Number"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetForm}
                  className="px-3.5 py-2 rounded-xl border border-stone-300 text-stone-700 hover:bg-stone-100 font-semibold text-xs transition cursor-pointer flex items-center gap-1.5"
                >
                  <X className="w-3.5 h-3.5" /> Cancel / Reset
                </button>

                <button
                  type="button"
                  onClick={handleSaveAsPdf}
                  className="bg-blue-700 hover:bg-blue-600 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs transition cursor-pointer flex items-center gap-1.5"
                >
                  <Download className="w-4 h-4" /> Save as PDF
                </button>

                <button
                  type="button"
                  onClick={handlePrint}
                  className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs px-5 py-2 rounded-xl shadow-sm transition cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4" /> Print Certificate
                </button>
              </div>
            </div>
          </div>

          {/* Official Printable Certificate Viewport */}
          <div className="bg-white p-8 sm:p-12 rounded-2xl border-2 border-stone-300 shadow-xl max-w-4xl mx-auto printable-document relative overflow-hidden">
            {/* Watermark Center Seal Background */}
            <div className="absolute inset-0 flex items-center justify-center opacity-[0.035] pointer-events-none select-none">
              <SealMunicipality className="w-[520px] h-[520px]" />
            </div>

            {/* Certificate Header with 3 Seals */}
            <div className="text-center relative z-10 border-b-2 border-emerald-900 pb-5">
              <div className="flex items-center justify-between gap-4 mb-2">
                {/* Left Seal: DA */}
                <div className="w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center shrink-0">
                  <SealDA className="w-full h-full object-contain" />
                </div>

                {/* Center Institution Text */}
                <div className="flex-1">
                  <p className="text-[10px] sm:text-xs uppercase tracking-widest text-stone-600 font-bold">
                    Republic of the Philippines
                  </p>
                  <p className="text-[10px] sm:text-xs uppercase tracking-widest text-stone-600 font-semibold">
                    Province of Southern Leyte
                  </p>
                  <h2 className="text-base sm:text-xl font-black text-emerald-950 tracking-wide mt-0.5">
                    {config.municipalityName}
                  </h2>
                  <h3 className="text-xs sm:text-sm font-bold text-emerald-800">
                    {config.officeName}
                  </h3>
                  <p className="text-[10px] text-stone-500 mt-0.5">
                    Municipal Agriculture & Veterinary Extension Division • Hinunangan
                  </p>
                </div>

                {/* Right Seal: Municipality Seal */}
                <div className="w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center shrink-0">
                  <SealMunicipality className="w-full h-full object-contain" />
                </div>
              </div>

              <div className="mt-4">
                <span className="text-[10px] uppercase font-mono tracking-wider text-stone-500 bg-stone-100 px-3 py-1 rounded-full border border-stone-200">
                  OFFICIAL CONTROL NO: <strong>{issuedControlNo}</strong>
                </span>
                <h1 className="text-base sm:text-lg font-black text-emerald-950 uppercase tracking-tight mt-3">
                  {activeCertificateTitle}
                </h1>
              </div>
            </div>

            {/* Letter Body */}
            <div className="py-6 space-y-4 text-xs sm:text-sm text-stone-800 leading-relaxed relative z-10">
              <div className="font-bold text-stone-900 tracking-wide text-xs flex items-center justify-between">
                <span>TO WHOM IT MAY CONCERN:</span>
                <span className="text-[11px] text-stone-500 font-normal">
                  Date of Inspection: {new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })}
                </span>
              </div>

              <p className="whitespace-pre-line text-justify text-stone-700">
                {certificateType === 'New Certificate'
                  ? `THIS IS TO CERTIFY that the swine described below has been properly registered, inspected, and documented in the official Hinunangan Swine Registry System in compliance with Municipal Agriculture ordinances and African Swine Fever (ASF) biosecurity protocols.`
                  : config.letterBodyTemplate}
              </p>

              {/* Swine Identification Data Box */}
              {selectedSwine && (
                <div className="bg-stone-50 rounded-xl p-4 border border-stone-300 my-4 text-xs">
                  <h4 className="font-bold text-emerald-950 mb-2 uppercase text-[11px] border-b pb-1 border-stone-200 flex items-center justify-between">
                    <span>REGISTERED SWINE & RAISER PARTICULARS</span>
                    <span className="text-[10px] text-emerald-700 font-bold">STATUS: READY FOR SLAUGHTER / SALE</span>
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-2.5 gap-x-4">
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Official Ear Tag No:</span>
                      <strong className="font-mono text-sm text-emerald-950">{selectedSwine.earTagNo}</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Farmer / Raiser Name:</span>
                      <strong className="text-stone-900">{selectedSwine.farmerName}</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Origin Barangay:</span>
                      <strong className="text-stone-900">Brgy. {selectedSwine.barangay}, Hinunangan</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Breed / Classification:</span>
                      <strong className="text-stone-900">{selectedSwine.breed} ({selectedSwine.swineType})</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Verified Live Weight:</span>
                      <strong className="text-stone-900">{selectedSwine.weightKg} kg ({selectedSwine.ageWeeks} weeks)</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Buyer / Meat Trader:</span>
                      <strong className="text-stone-900">{buyerName}</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Destination Facility:</span>
                      <strong className="text-stone-900">{destinationBarangay}</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Destination Municipality:</span>
                      <strong className="text-stone-900">{destinationMunicipality}</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">ASF Biosecurity Status:</span>
                      <strong className="text-emerald-700">✓ CERTIFIED ASF-FREE / GREEN ZONE</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Validity Period:</span>
                      <strong className="text-stone-900">72 Hours from Issue Date</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Housing / Farm System:</span>
                      <strong className="text-stone-900">{selectedSwine.housingType || 'Semi-Commercial Pen'}</strong>
                    </div>
                    <div>
                      <span className="text-stone-500 text-[10px] block font-medium">Feed Sourcing:</span>
                      <strong className="text-stone-900">{selectedSwine.feedType || 'Commercial Swine Pellet'} (No Swill)</strong>
                    </div>
                  </div>
                </div>
              )}

              {/* Terms & Conditions */}
              <div className="text-[11px] text-stone-500 space-y-1">
                <span className="font-bold text-stone-700 block">Terms and Directives:</span>
                <ul className="list-disc pl-4 space-y-0.5">
                  {config.termsAndConditions?.map((term, i) => (
                    <li key={i}>{term}</li>
                  ))}
                </ul>
              </div>

              {/* Date of Issuance */}
              <div className="pt-2 text-xs">
                Issued this <strong>{new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })}</strong> at the Municipal Agriculture Office, Hinunangan, Southern Leyte.
              </div>
            </div>

            {/* Dynamic Signatories Section */}
            <div className="pt-8 border-t border-stone-200 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-xs relative z-10">
              {signatories.map(sig => (
                <div key={sig.id} className="space-y-1">
                  <div className="h-10"></div>
                  <p className="font-black text-stone-900 border-t border-stone-400 pt-1 uppercase">
                    {sig.name}
                  </p>
                  <p className="text-[11px] font-semibold text-stone-700">{sig.title}</p>
                  <p className="text-[10px] text-stone-500">{sig.office}</p>
                </div>
              ))}
            </div>

            {/* Bottom Verification Seal & QR code */}
            <div className="mt-8 pt-4 border-t border-stone-200 flex items-center justify-between text-[10px] text-stone-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-700" />
                <span>DA Hinunangan Swine Registry System • Tamper-proof livestock clearance</span>
              </div>
              <div className="font-mono">
                VERIFICATION CODE: DA-HN-{selectedSwine?.earTagNo || '000'}-{issuedControlNo}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

