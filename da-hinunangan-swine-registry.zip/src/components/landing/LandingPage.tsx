import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Users,
  MapPin,
  ShoppingBag,
  ArrowRight,
  LogIn,
  CheckCircle,
  ExternalLink,
  WifiOff,
  Sparkles,
  Megaphone,
  Phone,
  Mail,
  Clock,
  Play,
  Share2,
  Calendar,
} from 'lucide-react';
import { Barangay, LandingPageConfig, SwineRecord, UserAccount, UserRole } from '../../types';
import { LandingCmsConfig } from '../../types/landingCms';
import { landingCmsService } from '../../services/landingCmsService';
import { OfficialSealBadge } from '../common/OfficialSeals';
import { PWAInstallButton } from '../common/PWAInstallButton';

interface LandingPageProps {
  swineList: SwineRecord[];
  barangays: Barangay[];
  config: LandingPageConfig;
  accounts: UserAccount[];
  onSelectRole: (role: UserRole, user?: UserAccount) => void;
  onNavigateTab?: (tab: string) => void;
  onOpenLogin: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  swineList,
  barangays,
  accounts,
  onSelectRole,
  onOpenLogin,
}) => {
  const [cmsConfig, setCmsConfig] = useState<LandingCmsConfig>(() =>
    landingCmsService.getPublishedConfig()
  );

  useEffect(() => {
    const handleUpdate = () => {
      setCmsConfig(landingCmsService.getPublishedConfig());
    };
    window.addEventListener('da_landing_cms_updated', handleUpdate);
    return () => window.removeEventListener('da_landing_cms_updated', handleUpdate);
  }, []);

  const readyToSellCount = swineList.filter(s => !s.isArchived && s.readyToSell).length;
  const totalSwine = swineList.filter(s => !s.isArchived).length;
  const uniqueFarmers = new Set(swineList.filter(s => !s.isArchived).map(s => s.farmerName)).size;

  const adminAccount = accounts.find(a => a.role === 'admin') || accounts[0];
  const focalAccounts = accounts.filter(a => a.role === 'focal');
  const agentAccount = accounts.find(a => a.role === 'agent') || accounts[1];

  const bg = cmsConfig.interfaceBackground || {
    enabled: true,
    imageUrl: 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=2000&q=80',
    overlayOpacity: 35,
    overlayColor: '#064e3b',
    blur: 0,
    brightness: 100,
    position: 'center',
    fit: 'cover',
    fixed: true,
  };

  const hasBackground = Boolean(bg.imageUrl && bg.enabled !== false);
  const blurPx = bg.blur ?? (bg as any).blurLevel ?? 0;
  const brightnessVal = (bg.brightness ?? 100) / 100;

  const theme = cmsConfig.theme || {
    primaryColor: '#047857',
    secondaryColor: '#064e3b',
    accentColor: '#f59e0b',
    backgroundColor: '#ffffff',
    textColor: '#1c1917',
    headingColor: '#064e3b',
    buttonColor: '#047857',
    buttonTextColor: '#ffffff',
    headingFont: 'system-ui',
    bodyFont: 'system-ui',
  };

  return (
    <div
      className="relative min-h-screen text-stone-900 selection:bg-emerald-500 selection:text-white"
      style={{
        fontFamily: theme.bodyFont || 'system-ui',
        backgroundColor: theme.backgroundColor || '#ffffff',
        color: theme.textColor || '#1c1917',
      }}
    >
      {/* Background Layer */}
      {hasBackground && (
        <div
          className={`fixed inset-0 pointer-events-none z-0 ${bg.fixed !== false ? 'attachment-fixed' : ''}`}
          style={{
            backgroundImage: `url(${bg.imageUrl})`,
            backgroundSize: bg.fit || 'cover',
            backgroundPosition: bg.position || 'center',
            backgroundRepeat: bg.repeat || 'no-repeat',
            filter: `brightness(${brightnessVal}) blur(${blurPx}px)`,
          }}
        >
          <div
            className="absolute inset-0"
            style={{
              backgroundColor: bg.overlayColor || '#064e3b',
              opacity: (bg.overlayOpacity ?? 35) / 100,
            }}
          />
        </div>
      )}

      {/* Content wrapper */}
      <div className="relative z-10 space-y-16 pb-24">
        {/* Top Announcement Bar */}
        {cmsConfig.announcement?.enabled && (
          <div
            className="px-4 py-2.5 text-xs font-bold flex items-center justify-between gap-3 shadow-md sticky top-0 z-40"
            style={{
              backgroundColor: cmsConfig.announcement.bgColor || '#f59e0b',
              color: cmsConfig.announcement.textColor || '#451a03',
            }}
          >
            <div className="max-w-7xl mx-auto w-full flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Megaphone className="w-4 h-4 shrink-0" />
                <span className="leading-snug">{cmsConfig.announcement.text}</span>
              </div>
              {cmsConfig.announcement.linkText && (
                <a
                  href={cmsConfig.announcement.linkUrl || '#'}
                  className="underline uppercase tracking-wider font-black text-[11px] shrink-0 hover:opacity-80"
                >
                  {cmsConfig.announcement.linkText}
                </a>
              )}
            </div>
          </div>
        )}

        {/* Hero Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
          <div
            className="relative rounded-3xl overflow-hidden text-white p-8 sm:p-14 shadow-2xl border border-white/20"
            style={{
              backgroundImage: cmsConfig.heroBackgroundUrl ? `url(${cmsConfig.heroBackgroundUrl})` : undefined,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundColor: theme.secondaryColor || '#064e3b',
            }}
          >
            {/* Dark Color Overlay */}
            <div
              className="absolute inset-0"
              style={{
                backgroundColor: cmsConfig.heroOverlayColor || '#064e3b',
                opacity: (cmsConfig.heroOverlayOpacity ?? 75) / 100,
              }}
            />

            <div className="relative z-10 max-w-3xl space-y-6">
              {/* Badges & Official Seals */}
              <div className="flex flex-wrap items-center gap-3">
                <span className="bg-emerald-800/90 border border-emerald-400/40 text-emerald-200 px-3 py-1 rounded-full text-xs font-bold tracking-wide uppercase flex items-center gap-1.5 shadow-sm">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  {cmsConfig.heroBadgeText || 'Official Government Platform • Republic of the Philippines'}
                </span>
                <span className="bg-teal-900/90 border border-teal-400/40 text-teal-200 px-3 py-1 rounded-full text-xs font-bold tracking-wide flex items-center gap-1.5 shadow-sm">
                  <WifiOff className="w-3.5 h-3.5" /> 100% Offline Access Ready
                </span>
              </div>

              {/* Institutional Seals Row */}
              <div className="flex flex-wrap items-center gap-2 pt-1 pb-1">
                {(cmsConfig.officialLogos || [])
                  .filter(l => l.visible !== false && (l.showInHero || l.placement === 'hero' || l.placement === 'header_left' || !l.placement))
                  .map(logo => (
                    <div
                      key={logo.id}
                      className="bg-white/95 rounded-xl p-1.5 shadow-md flex items-center gap-2 border border-white/40 backdrop-blur-xs"
                    >
                      {logo.url && logo.url.trim() !== '' && logo.url !== '/icon.svg' ? (
                        <img
                          src={logo.url}
                          alt={logo.name || logo.label}
                          className="w-7 h-7 object-contain rounded-full drop-shadow-xs"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <OfficialSealBadge
                          type={logo.vectorComponent || 'SealDA'}
                          size={30}
                          showLabel={false}
                          customUrl={logo.url}
                        />
                      )}
                      <span className="text-[10px] font-extrabold text-stone-900 uppercase tracking-wider pr-1">
                        {logo.name || logo.label || logo.institution}
                      </span>
                    </div>
                  ))}
              </div>

              <h1
                className="text-3xl sm:text-5xl font-black tracking-tight leading-tight drop-shadow-md"
                style={{ fontFamily: theme.headingFont || 'system-ui' }}
              >
                {cmsConfig.heroTitle}
              </h1>

              <p className="text-sm sm:text-base text-emerald-100/95 leading-relaxed max-w-2xl font-normal drop-shadow-xs">
                {cmsConfig.heroSubtitle}
              </p>

              {/* Action Buttons */}
              <div className="pt-3 flex flex-wrap items-center gap-3">
                <button
                  onClick={onOpenLogin}
                  className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-300 hover:from-emerald-300 hover:to-teal-200 text-emerald-950 font-black text-xs sm:text-sm shadow-xl hover:shadow-2xl transition transform hover:-translate-y-0.5 flex items-center gap-2 cursor-pointer border border-emerald-200"
                >
                  <LogIn className="w-4 h-4 text-emerald-950" />
                  <span>Sign In / Portal Login</span>
                </button>

                <button
                  onClick={() => onSelectRole('admin', adminAccount)}
                  className="px-5 py-3.5 rounded-2xl bg-white text-emerald-950 font-black text-xs sm:text-sm hover:bg-emerald-50 shadow-xl hover:shadow-2xl transition transform hover:-translate-y-0.5 flex items-center gap-2 cursor-pointer"
                >
                  <span>Enter Admin Portal</span>
                  <ArrowRight className="w-4 h-4 text-emerald-800" />
                </button>

                <button
                  onClick={() => onSelectRole('focal', focalAccounts[0])}
                  className="px-5 py-3.5 rounded-2xl bg-emerald-800/95 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm border border-emerald-500/50 shadow-md transition flex items-center gap-2 cursor-pointer"
                >
                  <span>Focal Person Access</span>
                </button>

                <button
                  onClick={() => onSelectRole('agent', agentAccount)}
                  className="px-5 py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-amber-950 font-black text-xs sm:text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Meat Trader / Agent Portal</span>
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Statistics Section */}
        {cmsConfig.statsEnabled && (
          <section className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white/95 backdrop-blur-md p-6 rounded-2xl border border-stone-200 shadow-sm text-center">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider block">
                  Registered Swine
                </span>
                <span
                  className="text-3xl sm:text-4xl font-black mt-1 block"
                  style={{ color: theme.headingColor || '#064e3b' }}
                >
                  {totalSwine || cmsConfig.statSwineCount} Heads
                </span>
                <span className="text-[11px] text-stone-400 mt-1 block">Actively monitored</span>
              </div>

              <div className="bg-white/95 backdrop-blur-md p-6 rounded-2xl border border-amber-200 shadow-sm text-center bg-amber-50/30">
                <span className="text-xs font-bold text-amber-800 uppercase tracking-wider block">
                  Incoming Ready to Sell
                </span>
                <span className="text-3xl sm:text-4xl font-black text-amber-900 mt-1 block">
                  {readyToSellCount || cmsConfig.statMarketReadyCount} Heads
                </span>
                <span className="text-[11px] text-amber-700 mt-1 block">Market harvest ready</span>
              </div>

              <div className="bg-white/95 backdrop-blur-md p-6 rounded-2xl border border-stone-200 shadow-sm text-center">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider block">
                  Jurisdiction Barangays
                </span>
                <span
                  className="text-3xl sm:text-4xl font-black mt-1 block"
                  style={{ color: theme.headingColor || '#064e3b' }}
                >
                  {barangays.length || cmsConfig.statBarangayCount} Barangays
                </span>
                <span className="text-[11px] text-stone-400 mt-1 block">100% Hinunangan covered</span>
              </div>

              <div className="bg-white/95 backdrop-blur-md p-6 rounded-2xl border border-stone-200 shadow-sm text-center">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider block">
                  Registered Raisers
                </span>
                <span
                  className="text-3xl sm:text-4xl font-black mt-1 block"
                  style={{ color: theme.headingColor || '#064e3b' }}
                >
                  {uniqueFarmers || cmsConfig.statFarmerCount} Farmers
                </span>
                <span className="text-[11px] text-stone-400 mt-1 block">RSBSA verified</span>
              </div>
            </div>
          </section>
        )}

        {/* Portal Selection Cards */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-xl mx-auto mb-8">
            <h2
              className="text-2xl sm:text-3xl font-black tracking-tight"
              style={{
                fontFamily: theme.headingFont || 'system-ui',
                color: theme.headingColor || '#064e3b',
              }}
            >
              Role-Based Portal Access
            </h2>
            <p className="text-xs text-stone-500 mt-1.5">
              Access your dedicated interface with specialized permissions and tools.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Admin Card */}
            <div className="bg-white/95 backdrop-blur-md rounded-3xl p-6 border-2 border-stone-200 hover:border-emerald-600 shadow-sm hover:shadow-xl transition flex flex-col justify-between group">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold shadow-inner">
                  <ShieldCheck className="w-6 h-6 text-emerald-700" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-stone-900 group-hover:text-emerald-800 transition">
                    Municipal Admin Portal
                  </h3>
                  <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                    Full jurisdiction control for Municipal Agriculturists and Livestock Technicians.
                  </p>
                </div>
                <ul className="text-xs text-stone-600 space-y-1.5 pt-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" /> Full Registry & GIS Biosurveillance
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" /> Official Certificate & QR Generator
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" /> Landing Page & Media CMS
                  </li>
                </ul>
              </div>

              <button
                onClick={() => onSelectRole('admin', adminAccount)}
                className="mt-6 w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Enter Admin Portal</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Focal Person Card */}
            <div className="bg-white/95 backdrop-blur-md rounded-3xl p-6 border-2 border-stone-200 hover:border-teal-600 shadow-sm hover:shadow-xl transition flex flex-col justify-between group">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-800 flex items-center justify-center font-bold shadow-inner">
                  <Users className="w-6 h-6 text-teal-700" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-stone-900 group-hover:text-teal-800 transition">
                    Barangay Focal Portal
                  </h3>
                  <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                    For Barangay Agricultural Focal Persons, Kagawads, and Livestock Enumerators.
                  </p>
                </div>
                <ul className="text-xs text-stone-600 space-y-1.5 pt-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-teal-600 shrink-0" /> Filtered to assigned Barangay
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-teal-600 shrink-0" /> Rapid field swine registration
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-teal-600 shrink-0" /> Local biosecurity inspection alerts
                  </li>
                </ul>
              </div>

              <button
                onClick={() => onSelectRole('focal', focalAccounts[0])}
                className="mt-6 w-full py-2.5 rounded-xl bg-teal-700 hover:bg-teal-600 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Enter Focal Portal</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Meat Trader / Agent Card */}
            <div className="bg-white/95 backdrop-blur-md rounded-3xl p-6 border-2 border-stone-200 hover:border-amber-500 shadow-sm hover:shadow-xl transition flex flex-col justify-between group">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-900 flex items-center justify-center font-bold shadow-inner">
                  <ShoppingBag className="w-6 h-6 text-amber-700" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-stone-900 group-hover:text-amber-800 transition">
                    Meat Trader & Agent Portal
                  </h3>
                  <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                    Catalog of market-ready hogs for accredited Hinunangan buyers and butchers.
                  </p>
                </div>
                <ul className="text-xs text-stone-600 space-y-1.5 pt-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-amber-600 shrink-0" /> Exclusive view of ready-to-sell hogs
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-amber-600 shrink-0" /> Verified live weights & price estimates
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-amber-600 shrink-0" /> Direct raiser phone numbers for orders
                  </li>
                </ul>
              </div>

              <button
                onClick={() => onSelectRole('agent', agentAccount)}
                className="mt-6 w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Enter Agent Catalog ({readyToSellCount || cmsConfig.statMarketReadyCount} Available)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>

        {/* About & Academic Synergy Section */}
        <section id="about" className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="bg-white/95 backdrop-blur-md rounded-3xl p-8 sm:p-12 border border-stone-200 shadow-lg grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" /> {cmsConfig.aboutSubtitle}
              </span>
              <h2
                className="text-2xl sm:text-4xl font-black text-stone-900 tracking-tight"
                style={{ fontFamily: theme.headingFont || 'system-ui' }}
              >
                {cmsConfig.aboutTitle}
              </h2>
              <p className="text-stone-600 text-xs sm:text-sm leading-relaxed whitespace-pre-line">
                {cmsConfig.aboutDescription}
              </p>

              {/* Pillars */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3">
                {(cmsConfig.aboutPillars || []).map((pillar, idx) => (
                  <div key={idx} className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-1">
                    <span className="text-[11px] font-bold text-stone-400 font-mono">0{idx + 1}</span>
                    <h4 className="font-bold text-xs text-stone-900">{pillar.title}</h4>
                    <p className="text-[11px] text-stone-600 leading-snug">{pillar.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="rounded-3xl overflow-hidden shadow-xl border border-stone-200 aspect-4/3 relative bg-stone-900">
                <img
                  src={cmsConfig.aboutImageUrl}
                  alt={cmsConfig.aboutTitle}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Features & Modules Section */}
        <section id="features" className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-xl mx-auto mb-8">
            <h2
              className="text-2xl sm:text-3xl font-black tracking-tight"
              style={{
                fontFamily: theme.headingFont || 'system-ui',
                color: theme.headingColor || '#064e3b',
              }}
            >
              {cmsConfig.featuresTitle}
            </h2>
            <p className="text-xs text-stone-500 mt-1.5">{cmsConfig.featuresSubtitle}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {(cmsConfig.features || []).map(feature => (
              <div
                key={feature.id}
                className="bg-white/95 backdrop-blur-md p-6 rounded-2xl border border-stone-200 shadow-sm space-y-3"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center justify-center font-bold">
                  <ShieldCheck className="w-5 h-5 text-emerald-700" />
                </div>
                <h3 className="font-black text-sm text-stone-900">{feature.title}</h3>
                <p className="text-xs text-stone-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Gallery Section */}
        {(cmsConfig.galleryPhotos || []).some(p => p.showOnLanding) && (
          <section id="gallery" className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center max-w-xl mx-auto mb-8">
              <h2
                className="text-2xl sm:text-3xl font-black tracking-tight"
                style={{
                  fontFamily: theme.headingFont || 'system-ui',
                  color: theme.headingColor || '#064e3b',
                }}
              >
                {cmsConfig.galleryTitle}
              </h2>
              <p className="text-xs text-stone-500 mt-1.5">{cmsConfig.gallerySubtitle}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {(cmsConfig.galleryPhotos || [])
                .filter(p => p.showOnLanding)
                .map(photo => (
                  <div
                    key={photo.id}
                    className="bg-white/95 backdrop-blur-md rounded-2xl overflow-hidden border border-stone-200 shadow-sm group"
                  >
                    <div className="aspect-4/3 overflow-hidden bg-stone-900 relative">
                      <img
                        src={photo.imageUrl}
                        alt={photo.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <span className="absolute bottom-2 left-2 px-2.5 py-1 rounded-md bg-black/75 text-white text-[10px] font-bold">
                        {photo.category}
                      </span>
                    </div>
                    <div className="p-4 space-y-1">
                      <h4 className="font-bold text-xs text-stone-900">{photo.title}</h4>
                      <p className="text-[11px] text-stone-500 leading-snug">{photo.caption}</p>
                    </div>
                  </div>
                ))}
            </div>
          </section>
        )}

        {/* Official Updates & Social Media Feed */}
        {(cmsConfig.socialPosts || []).some(p => p.visible) && (
          <section id="social" className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center max-w-xl mx-auto mb-8">
              <h2
                className="text-2xl sm:text-3xl font-black tracking-tight"
                style={{
                  fontFamily: theme.headingFont || 'system-ui',
                  color: theme.headingColor || '#064e3b',
                }}
              >
                {cmsConfig.socialTitle || 'Official Updates & Social Media Feed'}
              </h2>
              <p className="text-xs text-stone-500 mt-1.5">
                {cmsConfig.socialSubtitle || 'Stay informed with the latest agricultural advisories, price bulletins, and veterinary schedules.'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {(cmsConfig.socialPosts || [])
                .filter(p => p.visible)
                .map(post => (
                  <div
                    key={post.id}
                    className="bg-white/95 backdrop-blur-md rounded-2xl p-5 border border-stone-200 shadow-sm flex flex-col justify-between"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-[11px] text-stone-400">
                        <span className="font-bold text-emerald-800 flex items-center gap-1">
                          <Share2 className="w-3.5 h-3.5" /> {post.author}
                        </span>
                        <span>{post.date}</span>
                      </div>
                      <h4 className="font-bold text-sm text-stone-900 leading-snug">{post.title}</h4>
                      <p className="text-xs text-stone-600 leading-relaxed">{post.content}</p>
                    </div>

                    <div className="pt-3 border-t border-stone-100 mt-4 flex items-center justify-between gap-2">
                      <span className="text-[10px] font-medium text-stone-400 truncate">
                        {post.noticeLabel || 'Official Municipal Notice'}
                      </span>
                      <a
                        href={post.postUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs font-bold text-blue-700 hover:text-blue-800 hover:underline flex items-center gap-1 shrink-0"
                      >
                        <span>{post.buttonText || 'View on Facebook'}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                ))}
            </div>
          </section>
        )}

        {/* Contact & Hotlines Section */}
        <section id="contact" className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="bg-emerald-950 text-white rounded-3xl p-8 sm:p-12 border border-emerald-800 shadow-xl grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Phone className="w-4 h-4" /> Official Municipal Agriculture Contact
              </span>
              <h3 className="text-2xl sm:text-3xl font-black">{cmsConfig.officeName}</h3>
              <p className="text-xs text-emerald-100/80 leading-relaxed">{cmsConfig.address}</p>
              <div className="space-y-2 pt-2 text-xs">
                <div className="flex items-center gap-2 text-emerald-200">
                  <Clock className="w-4 h-4 text-emerald-400" />
                  <span>{cmsConfig.officeHours}</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-200">
                  <Mail className="w-4 h-4 text-emerald-400" />
                  <span>{cmsConfig.contactEmail}</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-200">
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <span>Office: {cmsConfig.contactPhone}</span>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4 text-center">
              <span className="text-xs font-bold text-red-400 uppercase tracking-wider block">
                24/7 Rapid Response ASF Emergency Hotline
              </span>
              <a
                href={`tel:${cmsConfig.hotlineEmergency}`}
                className="text-2xl sm:text-3xl font-black text-amber-300 block hover:underline"
              >
                {cmsConfig.hotlineEmergency}
              </a>
              <p className="text-[11px] text-emerald-100/70 leading-relaxed">
                Call immediately to report symptoms, unusual pig illness, or request urgent veterinary inspection across any Hinunangan barangay.
              </p>
              <div className="pt-2 flex justify-center">
                <PWAInstallButton />
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="max-w-7xl mx-auto px-4 sm:px-6 pt-12 border-t border-stone-300/60 text-xs text-stone-600">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-3 md:col-span-2">
              <div className="flex items-center gap-2.5 font-bold text-stone-900 text-sm">
                <img
                  src={cmsConfig.footerLogoUrl || cmsConfig.systemLogoUrl || cmsConfig.websiteLogoUrl || '/icon.svg'}
                  alt="Logo"
                  className="w-7 h-7 object-contain rounded-md"
                  referrerPolicy="no-referrer"
                />
                <span>{cmsConfig.websiteTitle}</span>
              </div>
              <p className="text-[11px] leading-relaxed max-w-md text-stone-500">
                {cmsConfig.footerDescription}
              </p>
              {/* Seals in Footer */}
              <div className="flex flex-wrap items-center gap-2 pt-2">
                {(cmsConfig.officialLogos || [])
                  .filter(l => l.visible !== false && (l.showInFooter || l.placement === 'footer' || l.placement === 'partners' || !l.placement))
                  .map(logo => (
                    <div
                      key={logo.id}
                      className="bg-white p-1 rounded-lg border border-stone-200 shadow-2xs flex items-center gap-1.5"
                    >
                      {logo.url && logo.url.trim() !== '' && logo.url !== '/icon.svg' ? (
                        <img
                          src={logo.url}
                          alt={logo.name || logo.label}
                          className="w-5 h-5 object-contain rounded-full"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <OfficialSealBadge
                          type={logo.vectorComponent || 'SealDA'}
                          size={22}
                          showLabel={false}
                          customUrl={logo.url}
                        />
                      )}
                      <span className="text-[9px] font-bold text-stone-700">{logo.name || logo.label}</span>
                    </div>
                  ))}
              </div>
            </div>

            {/* Dynamic Footer Columns */}
            {(cmsConfig.footerColumns || []).map(col => (
              <div key={col.id} className="space-y-2">
                <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider">{col.title}</h4>
                <ul className="space-y-1.5 text-[11px]">
                  {col.links.map(link => (
                    <li key={link.id}>
                      <a href={link.url} className="text-stone-500 hover:text-emerald-700 transition">
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-12 pt-6 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-stone-400">
            <span>{cmsConfig.footerCopyright}</span>
            <span className="font-semibold text-emerald-800">
              Department of Agriculture • Municipality of Hinunangan • SLSU Extension
            </span>
          </div>
        </footer>
      </div>
    </div>
  );
};
